<?php
/**
 * Newspack child theme functions and definitions.
 *
 * Add your custom PHP in this file.
 * Only edit this file if you have direct access to it on your server (to fix errors if they happen).
 */




add_image_size( 'newspack-home-image', 800, 840, true );
add_image_size( 'newspack-mostimportent-larg-image', 600, 350, true );
add_image_size( 'newspack-mostimportent-image', 600, 600, true );


/*
 * Set post views count using post meta
 */
function setPostViews($postID) {
    $countKey = 'post_views_count';
    $count = get_post_meta($postID, $countKey, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $countKey);
        add_post_meta($postID, $countKey, '0');
    }else{
        $count++;
        update_post_meta($postID, $countKey, $count);
    }
}




/**
 * Custom template tags for the theme.
 */
