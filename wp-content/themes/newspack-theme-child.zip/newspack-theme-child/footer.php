<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Newspack
 */

?>

	<?php do_action( 'before_footer' ); ?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">

		<?php //remove_filter( 'get_the_date', 'newspack_convert_to_time_ago', 10, 2 ); ?>
		<?php //get_template_part( 'template-parts/footer/footer', 'branding' ); ?>
		

		<div class="site-info">

			<?php get_template_part( 'template-parts/footer/below-footer', 'widgets' ); ?>

			<div class="wrapper site-info-contain text-center">
				<?php
					$copyright_info   = get_bloginfo( 'name' );
					$custom_copyright = get_theme_mod( 'footer_copyright', '' );
					if ( ! empty( $custom_copyright ) ) {
						$copyright_info = $custom_copyright;
					}
				?>
				<?php if ( ! empty( $copyright_info ) ) : ?>
					<span class="copyright">&copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php echo esc_html( $copyright_info ); ?></span>
				<?php endif; ?>

				

				<?php
				if ( function_exists( 'the_privacy_policy_link' ) ) {
					the_privacy_policy_link( '', '' );
				}

				if ( ! is_active_sidebar( 'footer-1' ) || ( ! has_custom_logo() ) ) {
					newspack_social_menu_footer();
				}
				?>
			</div><!-- .wrapper -->
		</div><!-- .site-info -->
		<?php get_template_part( 'template-parts/footer/footer', 'widgets' ); ?>
		
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>
<script>
	
		
	




	jQuery(document).ready(function(){		
		if(jQuery(window).width() < 760 ){			
			jQuery(window).on("load scroll", function() { 	
				
				jQuery(".archive article .entry-container .entry-header h2.entry-title a").each(function(){
					var str = jQuery(this).text(); 
					var res = str.slice(0, 35);
					jQuery(this).text(res + " ...")
					
				});
			});	
			
			// For All Post page
			jQuery(".page-template-all-post-page .allPost #recentPostCount li .content h3 a").each(function(){
				var str = jQuery(this).text(); 
				var res = str.slice(0, 35);
				jQuery(this).text(res + " ...")			
			});
		};
		
		
		jQuery("article footer .tags-links span").text(function(index, text) { 
			return text.replace('Tagged:', 'Etiquetas:'); 
		});
	});
</script>

</body>
</html>
